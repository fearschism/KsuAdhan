package com.example.ksu_adhan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
